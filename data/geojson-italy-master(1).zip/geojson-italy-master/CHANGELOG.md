# Changelog

All notable changes to this project will be documented in this file.

Releases will be tagged with year[.version].

## [2023.1] June 2023
Municipalities merges and splits.
Geojson files are now compatible with pre-RFC 7946 GeoJSON spec.

## [2022.1] Sept 2022
Municipalities merges and splits.

## [2021.2] Jul 2021 
Two municipalities in the province of Pesaro switched to the province of Rimini, changing region from Marche to Emilia-Romagna.
This changes provincial and regional subdivisions.

## [2021.1] Feb 2021
Municipalities merges and splits. It appears as no change of province or region happened from the 2019 release.

## [2019] Jan 2019

Initial release

